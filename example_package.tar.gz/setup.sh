#!/bin/sh
# Nodeon Router Package setup script
PACKAGE_NAME="ExamplePackage"
echo Installing $PACKAGE_NAME