#!/bin/bash
#
# chkconfig: 35 90 12
# description: Example Service
#

# Get function from functions library
. /etc/init.d/functions

start() {
    initlog -c "echo -n Starting ExampleService: "
    
}